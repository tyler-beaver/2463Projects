function setup() {
  createCanvas(200, 100);
}

function draw() {
  background('rgb(120,350,10)');
  circle(50,50,80);
  square(110,10,80);
}
